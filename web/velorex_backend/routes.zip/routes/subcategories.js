const express = require('express');
const sql = require('mssql');
const router = express.Router();
require('dotenv').config();

const dbConfig = {
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  server: process.env.DB_SERVER,
  database: process.env.DB_DATABASE,
  port: parseInt(process.env.DB_PORT),
  options: { encrypt: false, trustServerCertificate: true },
};

// ✅ GET all subcategories
// ✅ GET all subcategories with category name!
// ✅ routes/subcategory.js
router.get('/', async (_, res) => {
  try {
    const pool = await poolPromise;
    const result = await pool.request().query(`
      SELECT 
        SubcategoryID AS SubcategoryID,
        Name AS Name,
        CategoryID AS CategoryID
      FROM Subcategories
    `);
    res.json(result.recordset);
  } catch (err) {
    console.error('❌ GET subcategories:', err);
    res.status(500).json({ error: err.message });
  }
});
// ✅ ADD subcategory
router.post('/', async (req, res) => {
  const { name, categoryId } = req.body;
  if (!name || !categoryId) {
    return res.status(400).json({ error: 'Name & CategoryId required' });
  }
  try {
    const pool = await sql.connect(dbConfig);
    await pool.request()
      .input('name', sql.NVarChar, name)
      .input('categoryId', sql.Int, categoryId)
      .query(`
        INSERT INTO Subcategories (Name, CategoryId, CreatedAt)
        VALUES (@name, @categoryId, GETDATE())
      `);
    res.status(201).json({ message: '✅ Subcategory created' });
  } catch (err) {
    console.error('❌ ADD subcategory:', err);
    res.status(500).json({ error: err.message });
  }
});

// ✅ UPDATE subcategory
router.put('/:id', async (req, res) => {
  const { id } = req.params;
  const { name, categoryId } = req.body;
  if (!name || !categoryId) {
    return res.status(400).json({ error: 'Name & CategoryId required' });
  }
  try {
    const pool = await sql.connect(dbConfig);
    await pool.request()
      .input('id', sql.Int, id)
      .input('name', sql.NVarChar, name)
      .input('categoryId', sql.Int, categoryId)
      .query(`
        UPDATE Subcategories
        SET Name = @name, CategoryId = @categoryId
        WHERE Id = @id
      `);
    res.json({ message: '✅ Subcategory updated' });
  } catch (err) {
    console.error('❌ UPDATE subcategory:', err);
    res.status(500).json({ error: err.message });
  }
});

// ✅ DELETE subcategory
router.delete('/:id', async (req, res) => {
  const { id } = req.params;
  try {
    const pool = await sql.connect(dbConfig);
    await pool.request()
      .input('id', sql.Int, id)
      .query(`DELETE FROM Subcategories WHERE Id = @id`);
    res.json({ message: '✅ Subcategory deleted' });
  } catch (err) {
    console.error('❌ DELETE subcategory:', err);
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
