const express = require('express');
const router = express.Router();
const sql = require('mssql');

// ✅ Replace with your config
const dbConfig = {
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  server: process.env.DB_SERVER,
  database: process.env.DB_DATABASE,
  port: parseInt(process.env.DB_PORT),
  options: { encrypt: false, trustServerCertificate: true },
};


// 📌 GET /api/orders — Get all orders with user & coupon info
router.get('/', async (req, res) => {
  try {
    let pool = await sql.connect(dbConfig);
    let result = await pool.request().query(`
      SELECT 
        o.OrderID,
        o.TotalAmount,
        o.PaymentStatus,
        o.ShippingAddress,
        o.CreatedAt,
        u.FullName,
        u.Email,
        c.Code AS CouponCode
      FROM Orders o
      JOIN Users u ON o.UserID = u.UserID
      LEFT JOIN Coupons c ON o.CouponID = c.CouponID
      ORDER BY o.CreatedAt DESC
    `);

    res.json(result.recordset);
  } catch (err) {
    console.error('Error fetching orders:', err);
    res.status(500).json({ message: 'Server error' });
  }
});

// 📌 GET /api/orders/:id/items — Get order items + product names
router.get('/:id/items', async (req, res) => {
  const orderId = parseInt(req.params.id);

  if (isNaN(orderId)) {
    return res.status(400).json({ message: 'Invalid Order ID' });
  }

  try {
    let pool = await sql.connect(dbConfig);
    let result = await pool.request()
      .input('OrderID', sql.Int, orderId)
      .query(`
        SELECT 
          oi.OrderItemID,
          oi.OrderID,
          oi.Quantity,
          oi.Price,
          p.ProductID,
          p.Name AS ProductName
        FROM OrderItems oi
        LEFT JOIN Products p ON oi.ProductID = p.ProductID
        WHERE oi.OrderID = @OrderID
      `);

    res.json(result.recordset);
  } catch (err) {
    console.error('Error fetching order items:', err);
    res.status(500).json({ message: 'Server error' });
  }
});

// 📌 PATCH /api/orders/:id — Update payment status
router.patch('/:id', async (req, res) => {
  const orderId = parseInt(req.params.id);
  const { paymentStatus } = req.body;

  if (!paymentStatus) {
    return res.status(400).json({ message: 'Payment status is required' });
  }

  try {
    let pool = await sql.connect(dbConfig);
    await pool.request()
      .input('OrderID', sql.Int, orderId)
      .input('PaymentStatus', sql.NVarChar(50), paymentStatus)
      .query(`
        UPDATE Orders
        SET PaymentStatus = @PaymentStatus
        WHERE OrderID = @OrderID
      `);

    res.json({ message: 'Payment status updated successfully' });
  } catch (err) {
    console.error('Error updating payment status:', err);
    res.status(500).json({ message: 'Server error' });
  }
});

module.exports = router;
