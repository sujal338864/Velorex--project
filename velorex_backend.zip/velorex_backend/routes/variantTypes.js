// // routes/variantTypes.js
// const express = require('express');
// const router = express.Router();
// const { sql, poolPromise } = require('../models/db');

// // ✅ GET all variant types
// router.get('/', async (req, res) => {
//   try {
//     const pool = await poolPromise;
//     const result = await pool.request().query('SELECT * FROM VariantTypes');
//     res.json(result.recordset);
//   } catch (err) {
//     console.error('❌ GET /varianttypes error:', err);
//     res.status(500).send(err.message);
//   }
// });

// // ✅ POST add variant type
// router.post('/', async (req, res) => {
//   const { VariantTypeName } = req.body;
//   try {
//     const pool = await poolPromise;
//     const result = await pool.request()
//       .input('VariantTypeName', sql.NVarChar, VariantTypeName)
//       .query('INSERT INTO VariantTypes (VariantTypeName) VALUES (@VariantTypeName)');
//     res.status(201).send('Variant type added!');
//   } catch (err) {
//     console.error('❌ POST /varianttypes error:', err);
//     res.status(500).send(err.message);
//   }
// });

// // ✅ PUT update variant type
// router.put('/:id', async (req, res) => {
//   const { id } = req.params;
//   const { VariantTypeName } = req.body;
//   try {
//     const pool = await poolPromise;
//     const result = await pool.request()
//       .input('id', sql.Int, id)
//       .input('VariantTypeName', sql.NVarChar, VariantTypeName)
//       .query('UPDATE VariantTypes SET VariantTypeName = @VariantTypeName WHERE VariantTypeID = @id');
//     res.send('Variant type updated!');
//   } catch (err) {
//     console.error('❌ PUT /varianttypes/:id error:', err);
//     res.status(500).send(err.message);
//   }
// });

// // ✅ DELETE variant type
// router.delete('/:id', async (req, res) => {
//   const { id } = req.params;
//   try {
//     const pool = await poolPromise;
//     const result = await pool.request()
//       .input('id', sql.Int, id)
//       .query('DELETE FROM VariantTypes WHERE VariantTypeID = @id');
//     res.send('Variant type deleted!');
//   } catch (err) {
//     console.error('❌ DELETE /varianttypes/:id error:', err);
//     res.status(500).send(err.message);
//   }
// });

// module.exports = router;
const express = require('express');
const router = express.Router();
const { sql, poolPromise } = require('../models/db');

router.get('/', async (req, res) => {
  try {
    const pool = await poolPromise;
    const result = await pool.request().query('SELECT * FROM VariantTypes');
    res.json(result.recordset);
  } catch (err) {
    console.error('Error fetching variant types:', err);
    res.status(500).send('Server error');
  }
});

router.post('/', async (req, res) => {
  const { VariantTypeName } = req.body;
  if (!VariantTypeName) return res.status(400).send('Name is required');
  try {
    const pool = await poolPromise;
    await pool.request()
      .input('VariantTypeName', sql.NVarChar(100), VariantTypeName)
      .query('INSERT INTO VariantTypes (VariantTypeName) VALUES (@VariantTypeName)');
    res.status(201).send('Created');
  } catch (err) {
    console.error('Error adding variant type:', err);
    res.status(500).send('Server error');
  }
});

router.put('/:id', async (req, res) => {
  const { id } = req.params;
  const { VariantTypeName } = req.body;
  if (!VariantTypeName) return res.status(400).send('Name is required');
  try {
    const pool = await poolPromise;
    await pool.request()
      .input('id', sql.Int, id)
      .input('VariantTypeName', sql.NVarChar(100), VariantTypeName)
      .query('UPDATE VariantTypes SET VariantTypeName = @VariantTypeName WHERE VariantTypeID = @id');
    res.send('Updated');
  } catch (err) {
    console.error('Error updating variant type:', err);
    res.status(500).send('Server error');
  }
});

router.delete('/:id', async (req, res) => {
  const { id } = req.params;
  try {
    const pool = await poolPromise;
    await pool.request()
      .input('id', sql.Int, id)
      .query('DELETE FROM VariantTypes WHERE VariantTypeID = @id');
    res.send('Deleted');
  } catch (err) {
    console.error('Error deleting variant type:', err);
    res.status(500).send('Server error');
  }
});

module.exports = router;

