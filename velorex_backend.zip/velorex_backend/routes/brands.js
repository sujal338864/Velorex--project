// routes/brands.js
const express = require('express');
const sql = require('mssql');
const router = express.Router();
require('dotenv').config();

const dbConfig = {
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  server: process.env.DB_SERVER,
  database: process.env.DB_DATABASE,
  port: parseInt(process.env.DB_PORT),
  options: { encrypt: false, trustServerCertificate: true },
};

// ✅ Get all brands
router.get('/', async (_, res) => {
  try {
    const pool = await poolPromise;
    const result = await pool.request().query(`
      SELECT 
        BrandID AS BrandID,
        Name AS Name,
        SubcategoryID AS SubcategoryID
      FROM Brands
    `);
    res.json(result.recordset);
  } catch (err) {
    console.error('❌ GET brands:', err);
    res.status(500).json({ error: err.message });
  }
});

// ✅ Add brand
router.post('/', async (req, res) => {
  const { name, subcategoryId } = req.body;
  if (!name || !subcategoryId) {
    return res.status(400).json({ error: 'Name and subcategoryId required' });
  }
  try {
    const pool = await sql.connect(dbConfig);
    await pool.request()
      .input('name', sql.NVarChar, name)
      .input('subcategoryId', sql.Int, subcategoryId)
      .query(`INSERT INTO Brands (Name, SubcategoryID) VALUES (@name, @subcategoryId)`);
    res.status(201).json({ success: true });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: err.message });
  }
});

// ✅ Update brand
router.put('/:id', async (req, res) => {
  const { id } = req.params;
  const { name, subcategoryId } = req.body;
  if (!name || !subcategoryId) {
    return res.status(400).json({ error: 'Name and subcategoryId required' });
  }
  try {
    const pool = await sql.connect(dbConfig);
    await pool.request()
      .input('id', sql.Int, id)
      .input('name', sql.NVarChar, name)
      .input('subcategoryId', sql.Int, subcategoryId)
      .query(`UPDATE Brands SET Name = @name, SubcategoryID = @subcategoryId WHERE BrandID = @id`);
    res.json({ success: true });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: err.message });
  }
});

// ✅ Delete brand
router.delete('/:id', async (req, res) => {
  const { id } = req.params;
  try {
    const pool = await sql.connect(dbConfig);
    await pool.request().input('id', sql.Int, id).query(`DELETE FROM Brands WHERE BrandID = @id`);
    res.json({ success: true });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
