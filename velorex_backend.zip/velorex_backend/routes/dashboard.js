const express = require('express');
const router = express.Router();
const { poolPromise } = require('../db');

router.get('/', async (_, res) => {
  try {
    const pool = await poolPromise;
    const products = await pool.request().query('SELECT COUNT(*) AS count FROM Products');
    const categories = await pool.request().query('SELECT COUNT(*) AS count FROM Categories');
    const subcategories = await pool.request().query('SELECT COUNT(*) AS count FROM Subcategories');

    res.json({
      products: products.recordset[0].count,
      categories: categories.recordset[0].count,
      subcategories: subcategories.recordset[0].count
    });
  } catch (err) {
    res.status(500).send(err.message);
  }
});

module.exports = router;
