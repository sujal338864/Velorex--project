const express = require('express');
const sql = require('mssql');
const multer = require('multer');
const path = require('path');

const router = express.Router();

const dbConfig = {
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  server: process.env.DB_SERVER,
  database: process.env.DB_DATABASE,
  port: parseInt(process.env.DB_PORT),
  options: { encrypt: false, trustServerCertificate: true },
};

const storage = multer.diskStorage({
  destination: (_, __, cb) => cb(null, 'uploads/products'),
  filename: (_, file, cb) => cb(null, Date.now() + path.extname(file.originalname)),
});
const upload = multer({ storage });


// ✅ Get all products with images
router.get('/', async (_, res) => {
  try {
    const pool = await sql.connect(dbConfig); // ✅ SAME as POST
    const result = await pool.request().query(`
      SELECT 
        p.ProductID,
        p.Name,
        p.Description,
        p.Price,
        p.Quantity,
        p.SubcategoryID,
        p.BrandID,
        sc.Name AS SubcategoryName,
        b.Name AS BrandName,
        pi.ImageURL
      FROM Products p
      LEFT JOIN Subcategories sc ON p.SubcategoryID = sc.SubcategoryID
      LEFT JOIN Brands b ON p.BrandID = b.BrandID
      LEFT JOIN ProductImages pi ON p.ProductID = pi.ProductID
    `);

    const products = {};
    result.recordset.forEach(row => {
      if (!products[row.ProductID]) {
        products[row.ProductID] = {
          ProductID: row.ProductID,
          Name: row.Name,
          Description: row.Description,
          Price: row.Price,
          Quantity: row.Quantity,
          SubcategoryID: row.SubcategoryID,
          BrandID: row.BrandID,
          SubcategoryName: row.SubcategoryName,
          BrandName: row.BrandName,
          imagePaths: []
        };
      }
      if (row.ImageURL) {
        products[row.ProductID].imagePaths.push(row.ImageURL);
      }
    });

    res.json(Object.values(products));
  } catch (err) {
    console.error('❌ GET /api/products:', err);
    res.status(500).json({ error: err.message });
  }
});



router.post('/', upload.array('images', 10), async (req, res) => {
  const {
    Name,
    Description,
    Price,
    OfferPrice,
    Quantity,
    SubcategoryID,
    BrandID,
    Variants,
  } = req.body;

  try {
    const pool = await sql.connect(dbConfig);

    const result = await pool.request()
      .input('Name', sql.NVarChar, Name)
      .input('Description', sql.NVarChar, Description)
      .input('Price', sql.Decimal(18, 2), Price)
      .input('OfferPrice', sql.Decimal(18, 2), OfferPrice || null)
      .input('Quantity', sql.Int, Quantity)
      .input('SubcategoryID', sql.Int, SubcategoryID)
      .input('BrandID', sql.Int, BrandID)
      .query(`
        INSERT INTO Products (Name, Description, Price, OfferPrice, Quantity, SubcategoryID, BrandID)
        OUTPUT INSERTED.ProductID
        VALUES (@Name, @Description, @Price, @OfferPrice, @Quantity, @SubcategoryID, @BrandID)
      `);

    const productId = result.recordset[0].ProductID;

    if (req.files && req.files.length) {
      for (const file of req.files) {
        await pool.request()
          .input('ProductID', sql.Int, productId)
          .input('ImageURL', sql.NVarChar, file.filename) // ✅ Correct column name
          .query(`
            INSERT INTO ProductImages (ProductID, ImageURL)
            VALUES (@ProductID, @ImageURL)
          `);
      }
    }

    if (Variants) {
      const variants = JSON.parse(Variants);
      for (const variant of variants) {
        await pool.request()
          .input('ProductID', sql.Int, productId)
          .input('Name', sql.NVarChar, variant.name)
          .input('Value', sql.NVarChar, variant.value)
          .query(`
            INSERT INTO ProductVariants (ProductID, Name, Value)
            VALUES (@ProductID, @Name, @Value)
          `);
      }
    }

    res.status(201).json({ success: true, productId });
  } catch (err) {
    console.error('❌ POST /api/products:', err);
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;


// const express = require('express');
// const router = express.Router();
// const { sql, poolPromise } = require('../models/db');
// const multer = require('multer');
// const path = require('path');

// // ✅ Multer storage
// const storage = multer.diskStorage({
//   destination: (_, __, cb) => cb(null, 'uploads/'),
//   filename: (_, file, cb) => cb(null, Date.now() + path.extname(file.originalname)),
// });
// const upload = multer({ storage });

// ✅ Get all products with images
// router.get('/', async (_, res) => {
//   try {
//     const pool = await poolPromise;
//     const result = await pool.request().query(`
//       SELECT 
//         p.ProductID,
//         p.Name,
//         p.Description,
//         p.Price,
//         p.Quantity,
//         p.SubcategoryID,
//         p.BrandID,
//         sc.Name AS SubcategoryName,
//         b.Name AS BrandName,
//         pi.ImageURL   -- ✅ CORRECT COLUMN NAME!
//       FROM Products p
//       LEFT JOIN Subcategories sc ON p.SubcategoryID = sc.SubcategoryID
//       LEFT JOIN Brands b ON p.BrandID = b.BrandID
//       LEFT JOIN ProductImages pi ON p.ProductID = pi.ProductID
//     `);

//     const products = {};

//     result.recordset.forEach(row => {
//       if (!products[row.ProductID]) {
//         products[row.ProductID] = {
//           ProductID: row.ProductID,
//           Name: row.Name,
//           Description: row.Description,
//           Price: row.Price,
//           Quantity: row.Quantity,
//           SubcategoryID: row.SubcategoryID,
//           BrandID: row.BrandID,
//           SubcategoryName: row.SubcategoryName,
//           BrandName: row.BrandName,
//           imagePaths: []   // ✅ always create empty array
//         };
//       }

//       // ✅ Only push if ImageURL is present
//       if (row.ImageURL) {
//         products[row.ProductID].imagePaths.push(row.ImageURL);
//       }
//     });

//     res.json(Object.values(products));
//   } catch (err) {
//     console.error('❌ GET /api/products:', err);
//     res.status(500).json({ error: err.message });
//   }
// });




// // ✅ Add product
// router.post('/', upload.array('images', 10), async (req, res) => {
//   const { Name, Description, Price, Quantity, SubcategoryID, BrandID } = req.body;
//   const imagePaths = req.files.map(f => f.filename);

//   try {
//     const pool = await poolPromise;

//     const result = await pool.request()
//       .input('Name', sql.NVarChar, Name)
//       .input('Description', sql.NVarChar, Description)
//       .input('Price', sql.Decimal(18, 2), Price)
//       .input('Quantity', sql.Int, Quantity)
//       .input('SubcategoryID', sql.Int, SubcategoryID)
//       .input('BrandID', sql.Int, BrandID)
//       .query(`
//         INSERT INTO Products (Name, Description, Price, Quantity, SubcategoryID, BrandID)
//         OUTPUT INSERTED.ProductID
//         VALUES (@Name, @Description, @Price, @Quantity, @SubcategoryID, @BrandID)
//       `);

//     const productId = result.recordset[0].ProductID;

//     for (const img of imagePaths) {
//       await pool.request()
//         .input('ProductID', sql.Int, productId)
//         .input('ImagePath', sql.NVarChar, img)
//         .query(`INSERT INTO ProductImages (ProductID, ImagePath) VALUES (@ProductID, @ImagePath)`);
//     }

//     res.status(201).json({ message: '✅ Product saved with images' });
//   } catch (err) {
//     console.error('❌ POST /api/products:', err);
//     res.status(500).json({ error: err.message });
//   }
// });

// // ✅ Delete product
// router.delete('/:id', async (req, res) => {
//   const { id } = req.params;
//   try {
//     const pool = await poolPromise;
//     await pool.request()
//       .input('id', sql.Int, id)
//       .query('DELETE FROM Products WHERE ProductID = @id');
//     res.send('✅ Product deleted');
//   } catch (err) {
//     console.error('❌ DELETE /api/products:', err);
//     res.status(500).json({ error: err.message });
//   }
// });

// module.exports = router;
