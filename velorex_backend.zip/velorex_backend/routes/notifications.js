// ✅ server.js (or notifications.js)

const express = require('express');
const sql = require('mssql');
const router = express.Router();

const config = {
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  server: process.env.DB_SERVER,
  database: process.env.DB_DATABASE,
  options: {
    encrypt: true,
    trustServerCertificate: true,
  },
};

// ✅ GET all notifications
router.get('/', async (_, res) => {
  try {
    const pool = await sql.connect(config);
    const result = await pool.request().query(`
      SELECT NotificationID, Title, Description, ImageUrl, SendDate
      FROM Notifications
      ORDER BY SendDate DESC
    `);
    res.json(result.recordset);
  } catch (err) {
    console.error(err);
    res.status(500).send(err.message);
  }
});

// ✅ POST new notification
router.post('/', async (req, res) => {
  try {
    const { title, description, imageUrl } = req.body;
    console.log(`POST: ${title} | ${description} | ${imageUrl}`);

    const pool = await sql.connect(config);
    await pool.request()
      .input('Title', sql.NVarChar, title)
      .input('Description', sql.NVarChar, description)
      .input('ImageUrl', sql.NVarChar, imageUrl)
      .input('SendDate', sql.DateTime, new Date()) // ✅ Always insert SendDate!
      .query(`
        INSERT INTO Notifications (Title, Description, ImageUrl, SendDate)
        VALUES (@Title, @Description, @ImageUrl, @SendDate)
      `);

    res.sendStatus(201);
  } catch (err) {
    console.error(err);
    res.status(500).send(err.message);
  }
});

// ✅ DELETE notification by ID
router.delete('/:id', async (req, res) => {
  const { id } = req.params;
  try {
    const pool = await sql.connect(config);
    const result = await pool.request()
      .input('Id', sql.Int, id)
      .query('DELETE FROM Notifications WHERE NotificationID = @Id');

    if (result.rowsAffected[0] > 0) {
      res.sendStatus(200);
    } else {
      res.status(404).send('Not found');
    }
  } catch (err) {
    console.error(err);
    res.status(500).send(err.message);
  }
});

module.exports = router;
