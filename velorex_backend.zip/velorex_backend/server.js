const express = require('express');
const sql = require('mssql');
const cors = require('cors');
const bodyParser = require('body-parser');
const multer = require('multer');
const path = require('path');
require('dotenv').config();

const app = express();
const PORT = 3000;

// ✅ Middlewares
app.use(cors());
app.use(bodyParser.json());
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));
const brandsRoutes = require('./routes/brands');
const categoriesRoutes = require('./routes/categories');
const subcategoriesRoutes = require('./routes/subcategories');

app.use('/api/brands', brandsRoutes);
app.use('/api/categories', categoriesRoutes);
app.use('/api/subcategories', subcategoriesRoutes);
// app.use('/api/products', productsRoutes);
// const subcategoriesRouter = require('./routes/subcategories');
// app.use('/api/subcategories', subcategoriesRouter);

// const brandsRouter = require('./routes/brands');
// app.use('/api/brands', brandsRouter);

// ✅ Multer config
const storage = multer.diskStorage({
  destination: (_, __, cb) => cb(null, 'uploads/'),
  filename: (_, file, cb) => cb(null, Date.now() + path.extname(file.originalname)),
});
const upload = multer({ storage });

// ✅ DB config
const dbConfig = {
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  server: process.env.DB_SERVER,
  database: process.env.DB_DATABASE,
  port: parseInt(process.env.DB_PORT),
  options: { encrypt: false, trustServerCertificate: true },
};

// ✅ Test DB connection on start
sql.connect(dbConfig).then(() => console.log('✅ DB connected'))
  .catch(err => console.error('❌ DB connection failed:', err));

// ✅ Routes mounting
const productRoutes = require('./routes/products');
const couponRoutes = require('./routes/coupons');
const notificationsRouter = require('./routes/notifications'); // ✅

app.use('/api/products', productRoutes);
app.use('/api/coupons', couponRoutes);
app.use('/api/notifications', notificationsRouter);

const variantTypesRoutes = require('./routes/variantTypes');
app.use('/api/varianttypes', variantTypesRoutes);


// ✅ Admin login
app.post('/api/admin/login', async (req, res) => {
  const { username, password } = req.body;

  try {
    const pool = await sql.connect(dbConfig);

    const result = await pool.request()
      .input('username', sql.NVarChar, username)
      .input('password', sql.NVarChar, password)
      .query('SELECT * FROM Users WHERE FullName = @username AND PasswordHash = @password AND IsAdmin = 1');

    if (result.recordset.length > 0) {
      res.status(200).json({ success: true });
    } else {
      res.status(401).json({ success: false, message: 'Invalid credentials' });
    }
  } catch (err) {
    res.status(500).send(err.message);
  }
});

// ✅ Categories
app.get('/api/categories', async (_, res) => {
  try {
    const pool = await sql.connect(dbConfig);
    const result = await pool.request().query('SELECT * FROM Categories');
    res.json(result.recordset);
  } catch (err) {
    res.status(500).send(err.message);
  }
});

app.post('/api/categories', async (req, res) => {
  const { name } = req.body;
  try {
    const pool = await sql.connect(dbConfig);
    await pool.request()
      .input('name', sql.NVarChar, name)
      .query('INSERT INTO Categories (Name) VALUES (@name)');
    res.status(201).send('✅ Category saved');
  } catch (err) {
    res.status(500).send(err.message);
  }
});

// ✅ Subcategories
app.get('/api/subcategories', async (_, res) => {
  try {
    const pool = await sql.connect(dbConfig);
    const result = await pool.request().query('SELECT * FROM Subcategories');
    res.json(result.recordset);
  } catch (err) {
    res.status(500).send(err.message);
  }
});

app.post('/api/subcategories', async (req, res) => {
  const { name, categoryId } = req.body;
  try {
    const pool = await sql.connect(dbConfig);
    await pool.request()
      .input('name', sql.NVarChar, name)
      .input('categoryId', sql.Int, categoryId)
      .query('INSERT INTO Subcategories (Name, CategoryID) VALUES (@name, @categoryId)');
    res.status(201).send('✅ Subcategory saved');
  } catch (err) {
    res.status(500).send(err.message);
  }
});

// ✅ Brands
app.get('/api/brands', async (_, res) => {
  try {
    const pool = await sql.connect(dbConfig);
    const result = await pool.request().query('SELECT * FROM Brands');
    res.json(result.recordset);
  } catch (err) {
    res.status(500).send(err.message);
  }
});

app.post('/api/brands', async (req, res) => {
  const { Name, SubcategoryId } = req.body;
  try {
    const pool = await sql.connect(dbConfig);
    await pool.request()
      .input('name', sql.NVarChar, Name)
      .input('subcategoryId', sql.Int, SubcategoryId)
      .query('INSERT INTO Brands (Name, SubcategoryId) VALUES (@name, @subcategoryId)');
    res.status(201).send('✅ Brand saved');
  } catch (err) {
    res.status(500).send(err.message);
  }
});

// ✅ Get all notifications
app.get('/api/notifications', async (req, res) => {
  try {
    const pool = await sql.connect(config);
    const result = await pool
      .request()
      .query('SELECT * FROM Notifications ORDER BY SendDate DESC');
    res.json(result.recordset);
  } catch (err) {
    console.error('❌ GET /api/notifications:', err);
    res.status(500).send(err.message);
  }
});

// ✅ Add a notification
app.post('/api/notifications', async (req, res) => {
  const { title, description, imageUrl } = req.body;

  if (!title || !description) {
    return res.status(400).json({ error: 'Title and description required' });
  }

  try {
    const pool = await sql.connect(config);
    await pool.request()
      .input('Title', sql.NVarChar, title)
      .input('Description', sql.NVarChar, description)
      .input('ImageUrl', sql.NVarChar, imageUrl)
      .input('SendDate', sql.DateTime, new Date())
      .query(`
        INSERT INTO Notifications (Title, Description, ImageUrl, SendDate)
        VALUES (@Title, @Description, @ImageUrl, @SendDate)
      `);

    res.status(201).json({ message: '✅ Notification added' });
  } catch (err) {
    console.error('❌ POST /api/notifications:', err);
    res.status(500).send(err.message);
  }
});

// ✅ Delete a notification
app.delete('/api/notifications/:id', async (req, res) => {
  const { id } = req.params;
  try {
    const pool = await sql.connect(config);
    const result = await pool.request()
      .input('Id', sql.Int, id)
      .query('DELETE FROM Notifications WHERE NotificationID = @Id');

    if (result.rowsAffected[0] > 0) {
      res.json({ message: '✅ Deleted' });
    } else {
      res.status(404).json({ error: 'Not found' });
    }
  } catch (err) {
    console.error('❌ DELETE /api/notifications:', err);
    res.status(500).send(err.message);
  }
});

// ✅ Start server
app.listen(PORT, () => {
  console.log(`🚀 Server running at http://localhost:${PORT}`);
});
